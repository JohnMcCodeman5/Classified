/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXS 51

int main()
{
    char username[MAXS], password[MAXS], rec[MAXS], passcheck[MAXS], answer[MAXS], mask[MAXS], answercheck[MAXS];
    int opc, err = 0, succ, sideopc;
    printf("Unesite broj pored zeljene opcije: \n");
    printf("1 - Nova Registracija\n");
    printf("2 - Login\n");
    printf("3 - Promena sifre\n");
    scanf("%d", &opc);
    printf("\n");
    if(opc == 1){
        FILE *fbaza = fopen("baza.txt", "a+");
        do{
            printf("Unesite novi username (bez razmaka ili karaktera '#'): \n");
            scanf("%s", username);
            
            if(err != 1){
                printf("Unesite novu sifru (bez razmaka ili karaktera '#'): \n");
            }
            scanf("%s", password);
            
             if(err != 1){
                printf("Izaberite bezbednosno pitanje: \n");
                printf("1. Ime mog prvog ljubimca? \n");
                printf("2. Ime mog omiljenog benda? \n");
                printf("3. Ime mog prvog nastavnika/ce? \n");
                printf("4. Omiljeni crtani iz detinjstva?: \n");
                printf("5. Ime prve simpatije? \n");
            }
            
            do{
                scanf("%d", &sideopc);
                if(sideopc < 1 || sideopc > 5){
                    printf("greska, probajte ponovo\n");
                }
            }while(sideopc < 1 || sideopc > 5);
            
            printf("Odgovor: (sve spojeno!)\n");
            scanf("%s", answer);
            for(int i = 0; i < 3; i++){
                if(i == 0){
                    strcpy(mask, username);
                }
                if(i == 1){
                    strcpy(mask, password);
                }
                if(i == 2){
                    strcpy(mask, answer);
                }
                for(int j = 0; mask[j] != '\0'; j++){
                    if(mask[j] == '#'){
                        err = 1;
                        printf("greska, probajte ponovo\n");
                        printf("\n");
                    } 
                 }
            }
            
            if(strlen(username) > 50 || strlen(answer) > 50 || strlen(password) > 50){
                err = 1;
                printf("greska, probajte ponovo\n");
            }
        }while(err == 1);
        
        strcat(username, "#USR");
        strcat(password, "#PSS");
        strcat(answer, "#ANS");
        fprintf(fbaza, "%s %s %s %d\n", username, password, answer, sideopc);
        printf("Novi nalog je uspesno kreiran!\n");
    }
    
    if(opc == 2){
        FILE *fbaza = fopen("baza.txt", "r+");
        do{
            rewind(fbaza);
            printf("Username: \n");
            scanf("%s", username);
            strcat(username, "#USR");
            while(fscanf(fbaza, "%s", rec) != EOF){
                if(strcmp(rec, username) == 0){
                    fscanf(fbaza, "%s", passcheck);
                    succ = 1;
                }
            }
            if(succ != 1){
                err = 1;
            }
            printf("Password: \n");
            scanf("%s", password);
            strcat(password, "#PSS");
            if(strcmp(password, passcheck) == 0){
                printf("Uspesna prijava!\n");
                err = 0;
            }
            else{
                err = 1;
                printf("\nGreska, lose uneti podaci\nPokusajte ponovo...\n");
            }
            
        }while(err == 1);
    }


    if(opc == 3){
        do{
            succ = 0;
            FILE *fbaza = fopen("baza.txt", "a+");
            printf("Unesite svoj username:\n");
            scanf("%s", username);
            strcat(username, "#USR");
            rewind(fbaza);
        
            while((fscanf(fbaza, "%s", rec)) != EOF){
                 if(strcmp(rec, username) == 0){
                    succ = 1;  
                    break;
                 }        
            }
            if(succ != 1){
                err = 1;
                printf("nema ga\n\n");
            }
        
            fscanf(fbaza, "%s", password);
            fscanf(fbaza, "%s", answercheck);
            fscanf(fbaza, "%d", &sideopc);
            
            printf("Odgovorite na sigurnosno pitanje:\n");
            switch(sideopc){
                case 1:
                printf("1. Ime mog prvog ljubimca? \n");
                break;
            
                case 2:
                printf("2. Ime mog omiljenog benda? \n");
                break;
            
                case 3:
                printf("3. Ime mog prvog nastavnika/ce? \n");
                break;
                
                case 4:
                printf("4. Omiljeni crtani iz detinjstva?: \n");
                break;
            
                case 5:
                printf("5. Ime prve simpatije: \n");
                break;
            }
            
            scanf("%s", answer);
            strcat(answer, "#ANS");
            if(strcmp(answer, answercheck) != 0){
                err = 1;
            }
            else{
                printf("za sad dobro\n");
            }
        }while(err == 1);    
    }
    return 0;
}
